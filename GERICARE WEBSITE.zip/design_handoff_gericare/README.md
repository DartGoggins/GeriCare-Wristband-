# Handoff: GeriCare — Research Prototype Website

## Overview

A single-page marketing / research website for **GeriCare**, a standalone 4G LTE–enabled smart wristband for periodic vital-signs monitoring in geriatric patients under the care of licensed caregivers in Home for the Aged institutions in Cebu City. The centerpiece is a **scroll-driven exploded view** of the wristband: as the user scrolls, eight hardware components separate from a central stack, with a synced sidebar showing the currently-focused component's detail and specs.

The site is aimed at two audiences:
1. Reviewers of the SINAG: ApriCari Grade 12 research study
2. Licensed caregivers being invited to participate in the accompanying survey

## About the Design Files

The files in this bundle are **design references created in HTML** — a prototype showing intended look and interaction, **not production code to copy directly**. The bundled HTML uses vanilla HTML/CSS + GSAP purely so it can render standalone during design review.

Your task is to **recreate this design in the target codebase's existing environment** (React + CSS Modules, Next.js + Tailwind, Vue, Astro, etc.) using its established patterns, component primitives, and styling conventions. If no environment exists yet, choose the framework best suited to a small marketing/research site (recommended: **Next.js + Tailwind** or **Astro** for static delivery + minimal JS).

## Fidelity

**High-fidelity (hifi).** Final colors, typography, spacing, layout grids, and interaction behavior are all locked. Recreate pixel-perfectly with the codebase's existing library primitives. The one exception: the component illustrations in the exploded view are hand-authored SVGs meant as **placeholders for eventual photoreal 3D renders** — the geometry, palette, and stacking order are correct, but the final site should replace them with rendered PNGs once available (see Assets § below).

---

## Screens / Views

There is one page. It is organized as seven vertically-stacked sections:

### 1. Top Bar (fixed)
- **Purpose**: Persistent brand + section nav.
- **Layout**: `position: fixed`, full-width, 60px tall. `display: flex; justify-content: space-between; align-items: center; padding: 18px 32px`.
- **Background**: `rgba(246,248,250,0.82)` + `backdrop-filter: blur(14px) saturate(1.1)`, `border-bottom: 1px solid #dfe6ee`.
- **Left**: 8px teal-blue dot with 3px soft-blue halo + wordmark `GeriCare · SINAG: ApriCari`.
- **Center**: Nav links (`Prototype`, `Research`, `Capabilities`, `Users`) — hidden below 720px.
- **Right**: Static caption `Cebu City · MMXXVI`.
- **Type**: `Geist Mono` 11px, `letter-spacing: 0.12em`, `text-transform: uppercase`, color `#3d4b58` (link default opacity 0.7 → 1 on hover).

### 2. Hero
- **Purpose**: Announce the thesis title and hand the user off to scroll.
- **Layout**: `max-width: 1240px; margin: 0 auto; padding: 130px 32px 80px; min-height: 100vh; display: grid; grid-template-columns: 1.1fr 1fr; gap: 60px; align-items: center;`. Collapses to single column below 900px.
- **Left column**:
  - Eyebrow pill: `Research Prototype · v0.1` — `Geist Mono` 11px uppercase, `#1f4b6b` text on `#dbeaf5` background, 6×12px padding, 2px radius, 6×6px dot before.
  - H1: `Newsreader` 400, `clamp(44px, 6vw, 84px)`, `line-height: 0.98`, `letter-spacing: -0.02em`, color `#0f1a24`. Italic `<em>` uses weight 300 and color `#1f4b6b`. Copy: `A quiet wristband / for the caregivers / who never sit down.` — three lines, `<em>` around "caregivers".
  - Lede: `Newsreader` 300, `clamp(17px, 1.4vw, 21px)`, `line-height: 1.55`, `#3d4b58`, `max-width: 52ch`, `text-wrap: pretty`.
  - Meta strip: 3-col grid, top border `1px solid #dfe6ee`, `padding-top: 24px`. Each cell has a `#7a8896` 10px uppercase label and a `#0f1a24` 11px 500-weight value. Cells: `Study / Grade 12 · SHS`, `Location / Cebu City, PH`, `Status / Feasibility`.
- **Right column** (`.hero-visual`):
  - Aspect `4/5`, 4px radius, `overflow: hidden`, `box-shadow: 0 40px 80px -30px rgba(15,26,36,.18), 0 0 0 1px #dfe6ee`.
  - Background gradient: `linear-gradient(180deg, #ffffff 0%, #eef3f8 100%)`.
  - Image `assets/prototype-reference.jpg` fills with `object-fit: cover; mix-blend-mode: multiply; filter: contrast(1.02) saturate(.85);`.
  - Two overlay tags (top-left `Fig. 01 — Working Prototype`, bottom-right `3D-printed · PLA`), `Geist Mono` 10px uppercase, `rgba(255,255,255,.85)` bg with 4px blur.
  - Scroll cue at bottom-center: label `Scroll to disassemble` + 1×32px vertical bar with `pulse` keyframe animation (`opacity .3 ↔ 1`, `scaleY .6 ↔ 1`, 1.8s ease-in-out infinite).

### 3. Section Head — "Fig. 02 — Exploded Assembly" / Eight parts, one wristband.
- **Layout**: `max-width: 1240px; margin: 0 auto; padding: 100px 32px 40px`.
- **Kicker**: `Geist Mono` 11px uppercase `#1f4b6b`, `margin-bottom: 18px`. Copy: `Fig. 02 — Exploded Assembly`.
- **H2**: `Newsreader` 400, `clamp(34px, 4.4vw, 58px)`, `line-height: 1.02`, `letter-spacing: -0.015em`, `#0f1a24`, `max-width: 18ch`. `<em>` for "one wristband." — italic, weight 300, `#1f4b6b`.
- **Deck**: `Newsreader` 300, 19px, `line-height: 1.55`, `#3d4b58`, `max-width: 60ch`, `text-wrap: pretty`.

### 4. Exploded View (THE MAIN INTERACTION)
- **Purpose**: Scroll-driven progressive disassembly of the wristband.
- **Container**: `.exploded-wrap { position: relative; height: 600vh }` — the 6-viewport-tall runway is what drives the scroll timeline.
- **Sticky stage**: `.exploded-sticky { position: sticky; top: 0; height: 100vh; display: grid; grid-template-columns: 1fr 380px; overflow: hidden; }`. Below 900px, sidebar hides and stage takes full width.
- **Background**: layered radial + linear gradient (see `--bg` / `--paper` tokens) with a subtle 60×60 grid backdrop masked by a radial ellipse — see the `.exploded-sticky::before` rule in the source.
- **Progress rail** (`.progress-rail`): 8 vertical ticks pinned to the right edge of the stage at `right: 20px; top: 50%`. Inactive tick = `20px × 2px`, `#dfe6ee`. Active tick = `32px × 2px`, `#1f4b6b`. 12px gap between ticks. Transition on `all .3s`.
- **Stack** (`.stack`): 340×340 area centered in the left column. Every component (`.comp`) is `position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%)` — GSAP overrides `x/y/rotate` inline, so keep the CSS translate for centering.
- **Components** — eight `.comp` divs, each with a small SVG illustration and a floating label:

  | # | Name | Data attr | Side | z | Fly-out target `(dx, dy, rot°)` |
  |---|---|---|---|---|---|
  | 0 | Top Casing (hex, OLED + red SOS) | `data-comp="0"` | right | 70 | `(   0, -420,  0)` |
  | 1 | OLED + SOS Plate | `data-comp="1"` | left  | 65 | `( -60, -300, -6)` |
  | 2 | ESP32 microcontroller | `data-comp="2"` | right | 60 | `( 260, -180,  8)` |
  | 3 | MAX30102 pulse / SpO₂ | `data-comp="3"` | left  | 55 | `(-320, -100, -4)` |
  | 4 | IR thermometer (MLX90614) | `data-comp="4"` | right | 50 | `( 330,   40,  6)` |
  | 5 | 4G LTE modem (SIM7600) | `data-comp="5"` | left  | 45 | `(-260,  160, -6)` |
  | 6 | Battery + TP4056 | `data-comp="6"` | right | 40 | `( 100,  280,  4)` |
  | 7 | Silicone strap | `data-comp="7"` | left  | 35 | `( -40,  400,  0)` |

- **Labels** (`.comp .label`): `Geist Mono` 10px uppercase `#0f1a24` on `#ffffff` with `1px solid #dfe6ee`, 2px radius, `padding: 6px 10px`, `box-shadow: 0 8px 20px -8px rgba(15,26,36,.12)`. Positioned 80px outside the component on its assigned side via `left/right: calc(100% + 80px); top: 50%; translateY(-50%)`. A 60×1px `#3d4b58` leader line (`::before`) connects the label back to the component edge. `<small>` inside is 9px, `#7a8896`, `letter-spacing: 0.1em`. Labels start `opacity: 0` and fade in during their component's fly-out step.
- **Sidebar** (`.exploded-side`): 380px wide, `#ffffff`, `padding: 60px 40px`, `border-left: 1px solid #dfe6ee`, vertically centered.
  - **Head row**: `Geist Mono` 11px uppercase `#7a8896`, `margin-bottom: 20px`, with a `count` on the right (`01 / 08` — the current index is `#0f1a24`).
  - **Slide container** (`.side-slides`): `position: relative; height: 280px` — slides stack absolutely and cross-fade.
  - **Slide** (`.side-slide`): `opacity: 0; transform: translateY(10px); transition: opacity .4s, transform .4s`. Active slide adds `.active` → `opacity: 1; transform: translateY(0)`.
  - Slide anatomy: `num` (Mono 11px `#1f4b6b`), `h3` (Newsreader 400, 32px, `line-height: 1.05`, `letter-spacing: -0.01em`, `#0f1a24`), `p` (Newsreader 300, 16px, `line-height: 1.55`, `#3d4b58`, `text-wrap: pretty`), `dl.specs` (2-col grid, `gap: 6px 20px`, top border `1px solid #dfe6ee`, `padding-top: 16px`; `dt` is Mono 10px uppercase `#7a8896`, `dd` is Mono 11px `#0f1a24`).
  - Slide copy: see the eight slides in `GeriCare.html` under `#slides` — content is final.

- **Scroll behavior (GSAP + ScrollTrigger)**:
  ```
  ScrollTrigger:
    trigger: '#exploded'
    start:   'top top'
    end:     'bottom bottom'
    scrub:   0.8
    onUpdate: idx = min(7, floor(progress * 7.999)); setActive(idx)
  Timeline: for each component i (0..7):
    tl.to(`.comp[data-comp="${i}"]`,
          { x: dx, y: dy, rotate: r, duration: 1, ease: 'power2.out' },
          i * 0.6)
    tl.to(`.comp[data-comp="${i}"] .label`,
          { opacity: 1, duration: 0.4 },
          i * 0.6 + 0.4)
  ```
  The `i * 0.6` stagger means components separate progressively rather than all at once. `setActive(i)` toggles the `.active` class on both the matching side-slide and the matching progress-rail tick and updates `#cur` text to a zero-padded index.

### 5. Abstract Section
- **Section head**: kicker `§ Abstract`, H2 `On caregiving, quietly measured.` (italic `<em>` on "quietly measured.").
- **Two-column layout** (`max-width: 1240px; padding: 40px 32px 100px; grid-template-columns: 1fr 1.4fr; gap: 80px`). Collapses at 900px.
- **Left column** (`.side`): `Geist Mono` 11px uppercase `#7a8896`, `line-height: 1.8`. Contains study metadata + a `.stat` block (top-bordered) with a `Newsreader` 300 56px `#0f1a24` numeral `R.A. 10173` above the caption `Data Privacy Act of 2012 / governs all responses collected.`
- **Right column** (`.body`): three `<p>` in `Newsreader` 300 20px, `line-height: 1.6`, `#0f1a24`, `text-wrap: pretty`. First paragraph uses a drop cap: `p:first-child::first-letter { font-size: 76px; float: left; line-height: .85; padding: 6px 12px 0 0; font-weight: 400; color: #1f4b6b }`.
- **Compliance block**: `margin-top: 36px; padding: 20px 24px; background: #dbeaf5; color: #1f4b6b; font-family: Geist; font-size: 13px; line-height: 1.6; border-radius: 2px`. Bold "Participation is voluntary." lead + full RA 10173 statement.

### 6. Features Section (dark)
- **Background**: `#0f1a24`; text default `#eef3f8`.
- **Section head**: kicker color `#7fb3d6`; H2 white with `#9dc9e6` italic `<em>`; deck `#a8b8c8`. Copy: `§ Capabilities` / `What the wristband reads.` (italic on "reads.")
- **Grid** (`.features-grid`): 4 columns, `gap: 1px`, wrapped in a `#1f2f3d` border/frame so the 1px gap reads as hairlines between cards. Below 900px → 2 cols.
- **Card** (`.feat`): `#0f1a24` bg, `padding: 40px 28px`, `min-height: 260px`, `display: flex; flex-direction: column; justify-content: space-between`. Hover → `#152332`, `transition: background .3s`.
  - Icon: 44×44 circle, `1px solid #2a3d4f`, color `#9dc9e6`, contains a stroke-1.5 line SVG (22×22). Icons: HR waveform, water drop, thermometer, globe with axis lines.
  - Title: `Newsreader` 400, 22px, `line-height: 1.15`, white.
  - Copy: `Geist` 300, 13px, `line-height: 1.55`, `#a8b8c8`.
  - Footer num: `Geist Mono` 10px, `#5a7085`, uppercase, `margin-top: 20px`. Format: `01 / bpm`, `02 / %`, `03 / °C`, `04 / net`.
- Card content is finalized — see `.feat` blocks in the HTML.

### 7. Users Section
- **Section head**: `§ Target Users` / `Two hands, one wrist.` (italic on "one wrist.").
- **Two-column grid** (`.users`): `padding: 100px 32px; grid-template-columns: 1fr 1fr; gap: 60px`. Collapses at 900px.
- **Cards** (`.user-card`): `padding: 40px 36px; background: #ffffff; border: 1px solid #dfe6ee; border-radius: 4px`.
  - Role tag: `Geist Mono` 10px uppercase `#7a8896` with a 24×1px `#7a8896` leader before it.
  - H3: `Newsreader` 400, 36px, `line-height: 1.05`, `letter-spacing: -0.01em`, `#0f1a24`.
  - Copy: `Newsreader` 300, 16px, `line-height: 1.6`, `#3d4b58`.
  - Attributes grid (`.attr`): 2×2, `gap: 16px`, top border `1px solid #dfe6ee`. Each cell has a Mono 10px `#7a8896` key over a `Geist` 14px `#0f1a24` value.
- **Primary variant** (`.user-card.primary`, used on the caregiver card): background `#1f4b6b`, text `#eef3f8`, H3 white, copy `#c8dae8`, role `#9dc9e6`, attr border `#2a5578`, attr keys `#7a97ae`, attr values white.

### 8. Footer
- **Wrapper**: `border-top: 1px solid #dfe6ee; padding: 60px 32px 40px; background: #f6f8fa`.
- **Inner** (`.foot-inner`): `max-width: 1240px`, 3-column grid (`2fr 1fr 1fr`), `gap: 60px`. Collapses to 1 column at 720px.
- **Column 1 — brand**: `h5` label `Research group` (Mono 10px uppercase `#7a8896`), `h4` `SINAG: ApriCari` (Newsreader 400, 28px), `p` mission blurb (Newsreader 300, 15px, `#3d4b58`).
- **Columns 2 & 3 — link lists**: `h5` label + `<ul>` of 4 items (`Geist` 13px, `#3d4b58`, `line-height: 1.9`). Column 2 lists study meta, column 3 lists compliance points.
- **Bottom bar** (`.foot-bar`): top border, flex row, Mono 10px uppercase `#7a8896`. Left `© SINAG: ApriCari · GeriCare`, right `Fig. 02 / Exploded Assembly`.

---

## Interactions & Behavior

| Interaction | Trigger | Behavior |
|---|---|---|
| Top-bar nav click | Click anchor link | Native scroll to `#prototype`, `#abstract`, `#features`, or `#users`. |
| Exploded-view scroll | Any scroll while `#exploded` is in view | GSAP timeline `scrub: 0.8` maps scroll progress → component positions (x/y/rotate) and label opacity. Stage stays sticky for the full 600vh runway. |
| Slide + rail sync | GSAP `onUpdate` | Current index = `min(7, floor(progress * 7.999))`. Adds `.active` to the matching `.side-slide` and `.progress-rail .tick`; updates `#cur` text to two-digit index. |
| Scroll-cue pulse | Automatic | 1px×32px bar animates `opacity 0.3↔1` and `scaleY 0.6↔1` on a 1.8s `ease-in-out infinite` keyframe. |
| Feature-card hover | `:hover` on `.feat` | Background transitions from `#0f1a24` to `#152332` over 300ms. |
| Top-bar nav-link hover | `:hover` on `.topbar nav a` | Opacity 0.7 → 1 over 200ms. |
| Window resize | `resize` event | `ScrollTrigger.refresh()` recalculates positions. |

**No form validation, no data fetching, no error/loading states** — this is a static research site.

---

## Responsive Behavior

Two breakpoints in use:

- **≤ 900px**: Hero and abstract collapse to single-column. Exploded-view sidebar hides entirely; the stage takes the full column. Features grid becomes 2 columns. Users grid becomes 1 column.
- **≤ 720px**: Top-bar nav hides. Footer collapses to single column.

The exploded view SVG components are fixed pixel sizes; on smaller phones the stage still centers them at 340×340. If the target codebase supports it, consider scaling the whole stack with `transform: scale()` on narrow screens instead of just hiding the sidebar.

---

## State Management

Only three pieces of transient state, all managed inside the GSAP `onUpdate` callback — no persisted state, no route state, no auth:

- `currentIndex: 0..7` — derived from scroll progress; drives sidebar slide + progress rail + counter.
- `scrollProgress: 0..1` — GSAP internal; drives every component's transform.
- Resize listener → `ScrollTrigger.refresh()`.

In a React/Vue port, model `currentIndex` as component-local state and let a `useGsap` / `onMounted` hook wire the ScrollTrigger. Do not re-implement the scrub math manually — GSAP ScrollTrigger is doing the heavy lifting.

---

## Design Tokens

Copy these into your token file / Tailwind config exactly.

### Colors
```
--bg:        #f6f8fa   /* page background */
--paper:     #ffffff   /* cards / sidebar */
--ink:       #0f1a24   /* primary text, dark-section bg */
--ink-2:     #3d4b58   /* secondary text */
--muted:     #7a8896   /* tertiary text / labels */
--hair:      #dfe6ee   /* hairline borders */
--blue:      #4a90c2   /* brand dot */
--blue-soft: #dbeaf5   /* eyebrow pill, compliance bg */
--blue-deep: #1f4b6b   /* accent text, primary user card */
--mint:      #52b39a   /* OLED waveform accent */
--mint-soft: #d3ecdf   /* reserved / unused currently */
--danger:    #d94a4a   /* SOS button */
```

Dark-section auxiliaries (features section):
```
#152332  /* feat hover bg */
#1f2f3d  /* dark grid frame */
#2a3d4f  /* feat icon border */
#5a7085  /* feat num text */
#7fb3d6  /* dark-section kicker */
#9dc9e6  /* feat icon color, dark-section H2 em */
#a8b8c8  /* feat body copy */
#2a5578  /* primary user-card border */
#7a97ae  /* primary user-card attr key */
#c8dae8  /* primary user-card body */
```

### Typography
- **Serif display**: `Newsreader` (weights 300, 400, 500; italics 300, 400) — via Google Fonts.
- **Sans body**: `Geist` (weights 300, 400, 500, 600) — via Google Fonts.
- **Mono labels**: `Geist Mono` (weights 400, 500).
- Font stack fallbacks are in the `:root` in the HTML.

### Type scale (locked)
| Role | Font | Weight | Size | Line-height | Letter-spacing |
|---|---|---|---|---|---|
| Hero H1 | Newsreader | 400 (italic 300) | `clamp(44px, 6vw, 84px)` | 0.98 | -0.02em |
| Section H2 | Newsreader | 400 (italic 300) | `clamp(34px, 4.4vw, 58px)` | 1.02 | -0.015em |
| Card H3 | Newsreader | 400 | 32–36px | 1.05 | -0.01em |
| Feature H4 | Newsreader | 400 | 22px | 1.15 | -0.005em |
| Lede | Newsreader | 300 | `clamp(17px, 1.4vw, 21px)` | 1.55 | — |
| Body serif | Newsreader | 300 | 20px | 1.6 | — |
| Body sans | Geist | 300–400 | 13–14px | 1.55 | — |
| Kicker / label | Geist Mono | 400 | 10–11px | — | 0.12–0.18em |
| Meta value | Geist | 500 | 11px | — | — |

### Spacing (observed, not on a strict scale)
Section vertical rhythm: 100–130px top, 40–120px bottom. Container `max-width: 1240px`, side padding `32px`. Grid gaps in this order: 60px (large), 32px (medium), 16–20px (small), 6–12px (tight).

### Radii
- Cards / hero visual: **4px**
- Pills, tags, compliance block, sidebar chrome: **2px**
- Brand dot: **50%**

### Shadows
- Hero visual: `0 40px 80px -30px rgba(15,26,36,.18), 0 0 0 1px #dfe6ee`
- Label pop-in: `0 8px 20px -8px rgba(15,26,36,.12)`

### Motion
- Component fly-out: GSAP `power2.out`, `duration: 1`, staggered 0.6s per component, scrubbed at 0.8.
- Label fade: `duration: 0.4` inside the same scrub.
- Sidebar slide swap: CSS `transition: opacity .4s ease, transform .4s ease`.
- Feature-card hover: `background .3s`.
- Nav-link hover: `opacity .2s`.
- Scroll-cue pulse: 1.8s ease-in-out infinite.

---

## Assets

| Asset | Type | Source | Notes |
|---|---|---|---|
| `assets/prototype-reference.jpg` | Photo | Uploaded by client (physical prototype photo) | Used in hero visual. Included in this bundle. |
| Component illustrations (8 total) | Inline SVG in `GeriCare.html` | Hand-authored placeholders | **Replace with photoreal 3D renders when available.** The 8 target components are: Top Casing (hex PLA), OLED + SOS Plate, ESP32, MAX30102 pulse/SpO₂, MLX90614 IR thermometer, SIM7600 4G LTE modem, 1000 mAh LiPo + TP4056, Silicone strap. When you swap in PNGs, keep the same `.comp` wrapper + `data-comp` index so the GSAP timeline continues to work. |
| Feature icons (4) | Inline SVG (Lucide-style, stroke 1.5) | Hand-authored in HTML | Freely replaceable with the target codebase's icon library (e.g. Lucide, Phosphor). |
| Fonts: Newsreader, Geist, Geist Mono | Web font | Google Fonts | Load via `<link>` or self-host — both are Open Font License. |
| GSAP + ScrollTrigger 3.12.5 | JS library | `unpkg.com/gsap@3.12.5` | Client-only. In React, use `useGSAP` from `@gsap/react`. |

---

## Files

- `GeriCare.html` — the complete prototype (all sections, all CSS, all JS in one file). This is the canonical reference.
- `assets/prototype-reference.jpg` — the physical-prototype photo used in the hero visual.

## Implementation Recommendations

1. **Framework**: Next.js (App Router) + Tailwind — the site is static, marketing-shaped, and benefits from prerendering. Astro is an equally good fit if the team prefers zero-JS-by-default.
2. **Component decomposition**:
   - `<TopBar />`
   - `<Hero />`
   - `<ExplodedView />` — mounts GSAP + ScrollTrigger; owns the 8-item `COMPONENTS` array (fly-out coords + label text + slide copy) so the visual list and sidebar list can never drift out of sync again.
   - `<AbstractSection />`
   - `<FeaturesSection />` with `<FeatureCard />` children
   - `<UsersSection />` with `<UserCard variant="primary" | "default" />`
   - `<SiteFooter />`
3. **The exploded view is the whole product.** Give it 60–70 % of implementation effort. Everything else is straightforward marketing layout.
4. **Accessibility**:
   - Provide a `prefers-reduced-motion` fallback: skip the GSAP scrub and just fade in components as they enter the viewport (or show them pre-exploded as a static diagram).
   - The exploded view is a graphic; the sidebar slides carry the semantic content. Make sure the sidebar is fully readable without the animation — screen-reader users should get all 8 detail cards in DOM order.
   - Ensure all interactive elements have `:focus-visible` outlines using the `--blue-deep` token.
5. **Swap SVG → PNG plan**: once photoreal component renders exist, replace each SVG inside `.comp[data-comp="N"]` with an `<img>` of matching visual size. Keep the wrapper `.comp` div, `data-comp` index, `data-side` attribute, and the `.label` child — the GSAP config addresses components by data attribute, not by inner content.
